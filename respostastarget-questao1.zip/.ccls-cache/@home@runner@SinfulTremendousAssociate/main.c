#include <stdio.h>

int main(void) {
int INDICE = 13, SOMA = 0, K = 0;

for(K=0;K < INDICE;K++)
{
K = K + 1;
SOMA = SOMA + K;
}

printf("%d", SOMA);
  return 0;
}